let batchRecord = {
  documentNo: 'ADAPLC-OF-487',
  products: [],
  referenceDocuments: [],
  rawMaterials: [],
  processedMaterials: [],
  areaClearance: {
    steps: [],
    preparedBy: {},
    verifiedBy: {}
  },
  productionProcedure: {
    rawMaterialPreparation: [],
    rewiningProcedure: [],
    bleachingProcedure: [],
    drying: [],
    folding: []
  },
  samplingMaterialTransferStorage: {
    sampling: [],
    materialTransfer: [],
    storage: []
  },
  batchIssuance: {},
  postProduction: [],
  productRelease: {
    lotNo: '',
    mfgDate: '',
    expDate: '',
    roles: []
  }
};

function clearForm(formId) {
  const form = document.getElementById(formId);
  if (form) {
    form.reset();
    const fileInputs = form.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => input.value = '');
  }
}

async function addProduct() {
  const product = {
    productName: document.getElementById('product-name').value,
    colour: document.getElementById('colour').value,
    shape: document.getElementById('shape').value,
    batchSize: document.getElementById('batch-size').value,
    approxQuantity: document.getElementById('approx-quantity').value,
    packages: document.getElementById('packages').value,
    storageConditions: document.getElementById('storage-conditions').value
  };
  batchRecord.products.push(product);
  displayProducts();
  document.getElementById('products-form').reset();
  showSavedIndicator('product-name-saved');
}

async function addReferenceDocument() {
  const fileInput = document.getElementById('doc-file');
  const file = fileInput.files[0];
  const doc = {
    description: document.getElementById('doc-description').value,
    preparedBy: document.getElementById('doc-prepared-by').value,
    attachment: file ? file.name : '', // Store file name; use FileReader for content if needed
    date: document.getElementById('doc-date').value
  };
  batchRecord.referenceDocuments.push(doc);
  displayReferenceDocuments();
  document.getElementById('reference-documents-form').reset();
  fileInput.value = '';
}

async function saveReferenceDocuments() {
  displayReferenceDocuments();
  showSavedIndicator('doc-prepared-by-saved');
}

async function addRawMaterial() {
  const material = {
    name: document.getElementById('raw-name').value,
    code: document.getElementById('raw-code').value,
    weight: document.getElementById('raw-weight').value,
    lotNo: document.getElementById('raw-lot-no').value,
    qty: document.getElementById('raw-qty').value,
    performedBy: document.getElementById('raw-performed-by').value,
    checkedBy: document.getElementById('raw-checked-by').value,
    receivedBy: document.getElementById('raw-received-by').value
  };
  batchRecord.rawMaterials.push(material);
  displayRawMaterials();
  document.getElementById('raw-materials-form').reset();
}

async function saveRawMaterials() {
  displayRawMaterials();
  showSavedIndicator('raw-materials-saved');
}

async function addProcessedMaterial() {
  const pm = {
    description: document.getElementById('pm-description').value,
    idNo: document.getElementById('pm-id-no').value,
    previousCalibration: document.getElementById('pm-prev-cal').value,
    calibrationRequired: document.getElementById('pm-cal-required').value,
    performedBy: document.getElementById('pm-performed-by').value,
    verifiedBy: document.getElementById('pm-verified-by').value
  };
  batchRecord.processedMaterials.push(pm);
  displayProcessedMaterials();
  document.getElementById('processed-materials-form').reset();
}

async function saveProcessedMaterials() {
  displayProcessedMaterials();
  showSavedIndicator('processed-materials-saved');
}

async function addAreaClearanceStep() {
  const step = {
    sno: document.getElementById('ac-sno').value,
    step: document.getElementById('ac-step').value,
    performedBy: document.getElementById('ac-performed-by').value,
    verifiedBy: document.getElementById('ac-verified-by').value
  };
  batchRecord.areaClearance.steps.push(step);
  displayAreaClearance();
  document.getElementById('ac-sno').value = '';
  document.getElementById('ac-step').value = '';
  document.getElementById('ac-performed-by').value = '';
  document.getElementById('ac-verified-by').value = '';
}

async function saveAreaClearance() {
  const preparedFileInput = document.getElementById('ac-prepared-file');
  const verifiedFileInput = document.getElementById('ac-verified-file');
  const preparedFile = preparedFileInput.files[0];
  const verifiedFile = verifiedFileInput.files[0];
  batchRecord.areaClearance.preparedBy = {
    name: document.getElementById('ac-prepared-by').value,
    attachment: preparedFile ? preparedFile.name : '',
    date: document.getElementById('ac-date').value
  };
  batchRecord.areaClearance.verifiedBy = {
    name: document.getElementById('ac-verified-by-name').value,
    attachment: verifiedFile ? verifiedFile.name : '',
    date: document.getElementById('ac-verified-date').value
  };
  displayAreaClearance();
  document.getElementById('area-clearance-form').reset();
  preparedFileInput.value = '';
  verifiedFileInput.value = '';
  showSavedIndicator('ac-prepared-by-saved');
}

async function addProductionProcedure(type) {
  const pp = {
    step: document.getElementById(`pp-step-${type}`).value,
    performedBy: document.getElementById(`pp-performed-by-${type}`).value,
    verifiedBy: document.getElementById(`pp-verified-by-${type}`).value
  };
  if (!batchRecord.productionProcedure[type]) batchRecord.productionProcedure[type] = [];
  batchRecord.productionProcedure[type].push(pp);
  displayProductionProcedure();
  document.getElementById(`pp-step-${type}`).value = '';
  document.getElementById(`pp-performed-by-${type}`).value = '';
  document.getElementById(`pp-verified-by-${type}`).value = '';
}

async function saveProductionProcedure() {
  displayProductionProcedure();
  document.getElementById('production-procedure-form').reset();
  showSavedIndicator('production-procedure-saved');
}

async function addSampling() {
  batchRecord.samplingMaterialTransferStorage.sampling = [
    {
      description: document.getElementById('sampling-1').value,
      performedBy: document.getElementById('sampling-1-performed-by').value,
      verifiedBy: document.getElementById('sampling-1-verified-by').value
    },
    {
      description: document.getElementById('sampling-2').value,
      performedBy: document.getElementById('sampling-2-performed-by').value,
      verifiedBy: document.getElementById('sampling-2-verified-by').value
    },
    {
      description: document.getElementById('sampling-3').value,
      performedBy: document.getElementById('sampling-3-performed-by').value,
      verifiedBy: document.getElementById('sampling-3-verified-by').value
    },
    {
      description: document.getElementById('sampling-4').value,
      performedBy: document.getElementById('sampling-4-performed-by').value,
      verifiedBy: document.getElementById('sampling-4-verified-by').value
    }
  ];
  batchRecord.samplingMaterialTransferStorage.materialTransfer = [
    {
      description: document.getElementById('material-transfer-1').value,
      performedBy: document.getElementById('material-transfer-1-performed-by').value,
      verifiedBy: document.getElementById('material-transfer-1-verified-by').value
    }
  ];
  batchRecord.samplingMaterialTransferStorage.storage = [
    {
      description: document.getElementById('storage-1').value,
      performedBy: document.getElementById('storage-1-performed-by').value,
      verifiedBy: document.getElementById('storage-1-verified-by').value
    }
  ];
  displaySampling();
  document.getElementById('sampling-form').reset();
  showSavedIndicator('sampling-saved');
}

async function addBatchIssuance() {
  const issuedByFileInput = document.getElementById('bi-issued-by-file');
  const issuedToFileInput = document.getElementById('bi-issued-to-file');
  const issuedByFile = issuedByFileInput.files[0];
  const issuedToFile = issuedToFileInput.files[0];
  batchRecord.batchIssuance = {
    issuedBy: document.getElementById('bi-issued-by').value,
    issuedByAttachment: issuedByFile ? issuedByFile.name : '',
    issuedByDate: document.getElementById('bi-issued-by-date').value,
    issuedTo: document.getElementById('bi-issued-to').value,
    issuedToAttachment: issuedToFile ? issuedToFile.name : '',
    issuedToDate: document.getElementById('bi-issued-to-date').value
  };
  displayBatchIssuance();
  document.getElementById('batch-issuance-form').reset();
  issuedByFileInput.value = '';
  issuedToFileInput.value = '';
  showSavedIndicator('bi-issued-by-saved');
}

async function addPostProduction() {
  const file1Input = document.getElementById('pp-file-1');
  const file2Input = document.getElementById('pp-file-2');
  const file1 = file1Input.files[0];
  const file2 = file2Input.files[0];
  batchRecord.postProduction = [
    {
      department: document.getElementById('pp-department-1').value,
      name: document.getElementById('pp-name-1').value,
      attachment: file1 ? file1.name : '',
      date: document.getElementById('pp-date-1').value
    },
    {
      department: document.getElementById('pp-department-2').value,
      name: document.getElementById('pp-name-2').value,
      attachment: file2 ? file2.name : '',
      date: document.getElementById('pp-date-2').value
    }
  ];
  displayPostProduction();
  document.getElementById('post-production-form').reset();
  file1Input.value = '';
  file2Input.value = '';
  showSavedIndicator('post-production-saved');
}

async function addProductRelease() {
  const file1Input = document.getElementById('pr-file-1');
  const file2Input = document.getElementById('pr-file-2');
  const file3Input = document.getElementById('pr-file-3');
  const file1 = file1Input.files[0];
  const file2 = file2Input.files[0];
  const file3 = file3Input.files[0];
  batchRecord.productRelease = {
    lotNo: document.getElementById('pr-lot-no').value,
    mfgDate: document.getElementById('pr-mfg-date').value,
    expDate: document.getElementById('pr-exp-date').value,
    roles: [
      {
        role: document.getElementById('pr-role-1').value,
        name: document.getElementById('pr-name-1').value,
        attachment: file1 ? file1.name : '',
        date: document.getElementById('pr-date-1').value
      },
      {
        role: document.getElementById('pr-role-2').value,
        name: document.getElementById('pr-name-2').value,
        attachment: file2 ? file2.name : '',
        date: document.getElementById('pr-date-2').value
      },
      {
        role: document.getElementById('pr-role-3').value,
        name: document.getElementById('pr-name-3').value,
        attachment: file3 ? file3.name : '',
        date: document.getElementById('pr-date-3').value
      }
    ]
  };
  displayProductRelease();
  document.getElementById('product-release-form').reset();
  file1Input.value = '';
  file2Input.value = '';
  file3Input.value = '';
  showSavedIndicator('pr-lot-no-saved');
}

function displayProducts() {
  const list = document.getElementById('products-list');
  if (list) {
    list.innerHTML = batchRecord.products.map(p => `
      <div class="list">
        <p>Product Name: ${p.productName}</p>
        <p>Colour: ${p.colour}</p>
        <p>Shape: ${p.shape}</p>
        <p>Batch Size: ${p.batchSize}</p>
        <p>Approx Quantity: ${p.approxQuantity}</p>
        <p>Primary/Secondary Packages: ${p.packages}</p>
        <p>Storage Conditions: ${p.storageConditions}</p>
      </div>
    `).join('');
  }
}

function displayReferenceDocuments() {
  const list = document.getElementById('reference-documents-list');
  if (list) {
    list.innerHTML = batchRecord.referenceDocuments.map(d => `
      <div class="list">
        <p>Document Description: ${d.description}</p>
        <p>Prepared By: ${d.preparedBy}</p>
        <p>Attachment: ${d.attachment}</p>
        <p>Date: ${d.date}</p>
      </div>
    `).join('');
  }
}

function displayRawMaterials() {
  const list = document.getElementById('raw-materials-list');
  if (list) {
    list.innerHTML = batchRecord.rawMaterials.map(m => `
      <div class="list">
        <p>Name: ${m.name}</p>
        <p>Code: ${m.code}</p>
        <p>Weight: ${m.weight}</p>
        <p>Lot No: ${m.lotNo}</p>
        <p>Qty: ${m.qty}</p>
        <p>Performed By: ${m.performedBy}</p>
        <p>Checked By: ${m.checkedBy}</p>
        <p>Received By: ${m.receivedBy}</p>
      </div>
    `).join('');
  }
}

function displayProcessedMaterials() {
  const list = document.getElementById('processed-materials-list');
  if (list) {
    list.innerHTML = batchRecord.processedMaterials.map(pm => `
      <div class="list">
        <p>Description: ${pm.description}</p>
        <p>ID No.: ${pm.idNo}</p>
        <p>Previous Calibration: ${pm.previousCalibration}</p>
        <p>Calibration Required: ${pm.calibrationRequired}</p>
        <p>Performed By/Date: ${pm.performedBy}</p>
        <p>Verified By/Date: ${pm.verifiedBy}</p>
      </div>
    `).join('');
  }
}

function displayAreaClearance() {
  const list = document.getElementById('area-clearance-list');
  if (list) {
    list.innerHTML = `
      <div class="list">
        ${batchRecord.areaClearance.steps.map(s => `
          <p>S/No: ${s.sno}</p>
          <p>Step: ${s.step}</p>
          <p>Performed By: ${s.performedBy}</p>
          <p>Verified By/Date: ${s.verifiedBy}</p>
        `).join('')}
        <p>Prepared By (QA): ${batchRecord.areaClearance.preparedBy.name || ''}</p>
        <p>Attachment: ${batchRecord.areaClearance.preparedBy.attachment || ''}</p>
        <p>Date: ${batchRecord.areaClearance.preparedBy.date || ''}</p>
        <p>Verified By: ${batchRecord.areaClearance.verifiedBy.name || ''}</p>
        <p>Attachment: ${batchRecord.areaClearance.verifiedBy.attachment || ''}</p>
        <p>Date: ${batchRecord.areaClearance.verifiedBy.date || ''}</p>
      </div>
    `;
  }
}

function displayProductionProcedure() {
  const list = document.getElementById('production-procedure-list');
  if (list) {
    list.innerHTML = Object.entries(batchRecord.productionProcedure).map(([type, steps]) => `
      <div class="list">
        <h3>${type.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</h3>
        ${steps.map(s => `
          <p>Step: ${s.step}</p>
          <p>Performed By/Date: ${s.performedBy}</p>
          <p>Verified By/Date: ${s.verifiedBy}</p>
        `).join('')}
      </div>
    `).join('');
  }
}

function displaySampling() {
  const list = document.getElementById('sampling-list');
  if (list) {
    list.innerHTML = `
      <div class="list">
        ${batchRecord.samplingMaterialTransferStorage.sampling.map(item => `
          <p>Description: ${item.description}</p>
          <p>Performed By/Date: ${item.performedBy}</p>
          <p>Verified By/Date: ${item.verifiedBy}</p>
        `).join('')}
        ${batchRecord.samplingMaterialTransferStorage.materialTransfer.map(item => `
          <p>Description: ${item.description}</p>
          <p>Performed By/Date: ${item.performedBy}</p>
          <p>Verified By/Date: ${item.verifiedBy}</p>
        `).join('')}
        ${batchRecord.samplingMaterialTransferStorage.storage.map(item => `
          <p>Description: ${item.description}</p>
          <p>Performed By/Date: ${item.performedBy}</p>
          <p>Verified By/Date: ${item.verifiedBy}</p>
        `).join('')}
      </div>
    `;
  }
}

function displayBatchIssuance() {
  const list = document.getElementById('batch-issuance-list');
  if (list) {
    list.innerHTML = batchRecord.batchIssuance.issuedBy ? `
      <div class="list">
        <p>Issued By: ${batchRecord.batchIssuance.issuedBy}</p>
        <p>Attachment: ${batchRecord.batchIssuance.issuedByAttachment}</p>
        <p>Date: ${batchRecord.batchIssuance.issuedByDate}</p>
        <p>Issued To: ${batchRecord.batchIssuance.issuedTo}</p>
        <p>Attachment: ${batchRecord.batchIssuance.issuedToAttachment}</p>
        <p>Date: ${batchRecord.batchIssuance.issuedToDate}</p>
      </div>
    ` : '';
  }
}

function displayPostProduction() {
  const list = document.getElementById('post-production-list');
  if (list) {
    list.innerHTML = batchRecord.postProduction.map(pp => `
      <div class="list">
        <p>Department: ${pp.department}</p>
        <p>Name: ${pp.name}</p>
        <p>Attachment: ${pp.attachment}</p>
        <p>Date: ${pp.date}</p>
      </div>
    `).join('');
  }
}

function displayProductRelease() {
  const list = document.getElementById('product-release-list');
  if (list) {
    list.innerHTML = `
      <div class="list">
        <p>Lot No: ${batchRecord.productRelease.lotNo}</p>
        <p>MFG Date: ${batchRecord.productRelease.mfgDate}</p>
        <p>EXP Date: ${batchRecord.productRelease.expDate}</p>
        ${batchRecord.productRelease.roles.map(r => `
          <div>
            <p>Role: ${r.role}</p>
            <p>Name: ${r.name}</p>
            <p>Attachment: ${r.attachment}</p>
            <p>Date: ${r.date}</p>
          </div>
        `).join('')}
      </div>
    `;
  }
}

async function submitReport() {
  try {
    const response = await fetch('http://localhost:5000/api/batch-records', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(batchRecord)
    });
    const data = await response.json();
    alert('Report submitted successfully!');
    batchRecord = {
      documentNo: 'ADAPLC-OF-487',
      products: [],
      referenceDocuments: [],
      rawMaterials: [],
      processedMaterials: [],
      areaClearance: { steps: [], preparedBy: {}, verifiedBy: {} },
      productionProcedure: { rawMaterialPreparation: [], rewiningProcedure: [], bleachingProcedure: [], drying: [], folding: [] },
      samplingMaterialTransferStorage: { sampling: [], materialTransfer: [], storage: [] },
      batchIssuance: {},
      postProduction: [],
      productRelease: { lotNo: '', mfgDate: '', expDate: '', roles: [] }
    };
    updateAllDisplays();
  } catch (error) {
    console.error('Error submitting report:', error);
    alert('Error submitting report');
  }
}

function exportToPDF() {
  alert('PDF export functionality requires a library like jsPDF. Implement it based on your needs.');
}

function updateAllDisplays() {
  displayProducts();
  displayReferenceDocuments();
  displayRawMaterials();
  displayProcessedMaterials();
  displayAreaClearance();
  displayProductionProcedure();
  displaySampling();
  displayBatchIssuance();
  displayPostProduction();
  displayProductRelease();
}

function showSavedIndicator(id) {
  const savedElement = document.getElementById(id);
  if (savedElement) {
    savedElement.style.display = 'inline';
    setTimeout(() => { savedElement.style.display = 'none'; }, 2000);
  }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
  // Add Step Buttons
  const addStepButtons = {
    'add-step-btn': addAreaClearanceStep,
    'add-step-rawMaterialPreparation': () => addProductionProcedure('rawMaterialPreparation'),
    'add-step-rewiningProcedure': () => addProductionProcedure('rewiningProcedure'),
    'add-step-bleachingProcedure': () => addProductionProcedure('bleachingProcedure'),
    'add-step-drying': () => addProductionProcedure('drying'),
    'add-step-folding': () => addProductionProcedure('folding')
  };
  Object.entries(addStepButtons).forEach(([id, func]) => {
    const btn = document.getElementById(id);
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        func();
      });
    }
  });
  
  // Save Buttons
  const saveButtons = {
    'products-form': addProduct,
    'reference-documents-save': saveReferenceDocuments,
    'raw-materials-save': saveRawMaterials,
    'processed-materials-save': saveProcessedMaterials,
    'area-clearance-save': saveAreaClearance,
    'production-procedure-save': saveProductionProcedure,
    'sampling-save': addSampling,
    'batch-issuance-save': addBatchIssuance,
    'post-production-save': addPostProduction,
    'product-release-save': addProductRelease
  };
  Object.entries(saveButtons).forEach(([id, func]) => {
    const btn = document.getElementById(id) || document.querySelector(`#${id} button[type="submit"]`);
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        func();
      });
    }
  });
  
  // Attach Buttons
  const attachButtons = {
    'doc-attach': 'doc-file',
    'ac-prepared-attach': 'ac-prepared-file',
    'ac-verified-attach': 'ac-verified-file',
    'bi-issued-by-attach': 'bi-issued-by-file',
    'bi-issued-to-attach': 'bi-issued-to-file',
    'pp-attach-1': 'pp-file-1',
    'pp-attach-2': 'pp-file-2',
    'pr-attach-1': 'pr-file-1',
    'pr-attach-2': 'pr-file-2',
    'pr-attach-3': 'pr-file-3'
  };
  Object.entries(attachButtons).forEach(([btnId, inputId]) => {
    const btn = document.getElementById(btnId);
    if (btn) {
      btn.addEventListener('click', () => {
        document.getElementById(inputId).click();
      });
    }
  });
  
  // Clear Form Buttons
  const clearFormButtons = {
    'products-clear': 'products-form',
    'reference-documents-clear': 'reference-documents-form',
    'raw-materials-clear': 'raw-materials-form',
    'processed-materials-clear': 'processed-materials-form',
    'area-clearance-clear': 'area-clearance-form',
    'production-procedure-clear': 'production-procedure-form',
    'sampling-clear': 'sampling-form',
    'batch-issuance-clear': 'batch-issuance-form',
    'post-production-clear': 'post-production-form',
    'product-release-clear': 'product-release-form'
  };
  Object.entries(clearFormButtons).forEach(([btnId, formId]) => {
    const btn = document.getElementById(btnId);
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        clearForm(formId);
      });
    }
  });
});