const mongoose = require('mongoose');

const batchRecordSchema = new mongoose.Schema({
  documentNo: { type: String, required: true },
  products: [{
    productName: String,
    colour: String,
    shape: String,
    batchSize: String,
    approxQuantity: String,
    packages: String,
    storageConditions: String
  }],
  referenceDocuments: [{
    description: String,
    preparedBy: String,
    signature: String,
    date: String
  }],
  rawMaterials: [{
    name: String,
    code: String,
    weight: String,
    lotNo: String,
    qty: String,
    performedBy: String,
    checkedBy: String,
    receivedBy: String
  }],
  processedMaterials: [{
    description: String,
    idNo: String,
    previousCalibration: String,
    calibrationRequired: String,
    performedBy: String,
    verifiedBy: String
  }],
  areaClearance: [{
    step: String,
    performedBy: String,
    verifiedBy: String
  }],
  productionProcedure: {
    rawMaterialPreparation: [{ step: String, performedBy: String, verifiedBy: String }],
    rewiningProcedure: [{ step: String, performedBy: String, verifiedBy: String }],
    bleachingProcedure: [{ step: String, performedBy: String, verifiedBy: String }],
    drying: [{ step: String, performedBy: String, verifiedBy: String }],
    folding: [{ step: String, performedBy: String, verifiedBy: String }]
  },
  sampling: [{
    description: String,
    performedBy: String,
    verifiedBy: String
  }],
  batchIssuance: {
    issuedBy: String,
    issuedBySignature: String,
    issuedByDate: String,
    issuedTo: String,
    issuedToSignature: String,
    issuedToDate: String
  },
  postProduction: [{
    department: String,
    name: String,
    signature: String,
    date: String
  }],
  productRelease: {
    lotNo: String,
    mfgDate: String,
    expDate: String,
    roles: [{
      role: String,
      name: String,
      signature: String,
      date: String
    }]
  }
});

module.exports = mongoose.model('BatchRecord', batchRecordSchema);