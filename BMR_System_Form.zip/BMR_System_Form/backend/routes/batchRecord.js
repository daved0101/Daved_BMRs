const express = require('express');
const router = express.Router();
const BatchRecord = require('../models/batchRecord');

// Create a new batch record
router.post('/', async (req, res) => {
  try {
    const batchRecord = new BatchRecord(req.body);
    await batchRecord.save();
    res.status(201).json(batchRecord);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all batch records
router.get('/', async (req, res) => {
  try {
    const batchRecords = await BatchRecord.find();
    res.json(batchRecords);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update a batch record
router.put('/:id', async (req, res) => {
  try {
    const batchRecord = await BatchRecord.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(batchRecord);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;